using System;
using System.Threading.Tasks;
using Moq;
using Xunit;

namespace Course_Scheduler_AH_C971.Tests
{
    public class LoginTests
    {
        [Fact]
        public async Task OnLoginButtonClicked_ValidatesDifferentLoginScenarios()
        {
            // Arrange
            var mockDatabase = new Mock<IDatabaseHelper>();
            var mockNavigation = new Mock<INavigation>();

            var validTeacher = new User { UserId = 1, Password = "teacherPass", Role = "Teacher" };
            var validStudent = new User { UserId = 2, Password = "studentPass", Role = "Student" };

            mockDatabase.Setup(db => db.GetUserByIdAsync(1)).ReturnsAsync(validTeacher);
            mockDatabase.Setup(db => db.GetUserByIdAsync(2)).ReturnsAsync(validStudent);
            mockDatabase.Setup(db => db.GetUserByIdAsync(3)).ReturnsAsync((User)null); // User not found

            var loginPage = new Login(mockDatabase.Object)
            {
                Navigation = mockNavigation.Object
            };

            // Helper to mock DisplayAlert
            string alertMessage = null;
            loginPage.DisplayAlert = async (title, message, cancel) =>
            {
                alertMessage = message;
                await Task.CompletedTask;
            };

            // Act & Assert: Test valid Teacher login
            loginPage.Username = new Entry { Text = "1" };
            loginPage.Password = new Entry { Text = "teacherPass" };
            await loginPage.OnLoginButtonClicked(null, null);
            mockNavigation.Verify(nav => nav.PushAsync(It.IsAny<TeacherPage>()), Times.Once);

            // Act & Assert: Test invalid UserId format
            loginPage.Username = new Entry { Text = "abc" }; // Invalid UserId
            loginPage.Password = new Entry { Text = "password" };
            await loginPage.OnLoginButtonClicked(null, null);
            Assert.Equal("Invalid Username format", alertMessage);

            // Act & Assert: Test user not found
            loginPage.Username = new Entry { Text = "3" }; // UserId not in database
            loginPage.Password = new Entry { Text = "password" };
            await loginPage.OnLoginButtonClicked(null, null);
            Assert.Equal("User not found", alertMessage);

            // Act & Assert: Test incorrect password
            loginPage.Username = new Entry { Text = "2" };
            loginPage.Password = new Entry { Text = "wrongPassword" };
            await loginPage.OnLoginButtonClicked(null, null);
            Assert.Equal("Incorrect password", alertMessage);
        }

        // Dummy interfaces and classes for this test file to be self-contained
        public interface IDatabaseHelper
        {
            Task<User> GetUserByIdAsync(int userId);
        }

        public interface INavigation
        {
            Task PushAsync(object page);
        }

        public class Login
        {
            private readonly IDatabaseHelper _databaseHelper;
            public INavigation Navigation { get; set; }
            public Func<string, string, string, Task> DisplayAlert { get; set; }
            public Entry Username { get; set; }
            public Entry Password { get; set; }

            public Login(IDatabaseHelper databaseHelper)
            {
                _databaseHelper = databaseHelper;
            }

            public async Task OnLoginButtonClicked(object sender, EventArgs e)
            {
                if (!int.TryParse(Username.Text, out int userId))
                {
                    await DisplayAlert("Error", "Invalid Username format", "OK");
                    return;
                }

                var user = await _databaseHelper.GetUserByIdAsync(userId);
                if (user == null)
                {
                    await DisplayAlert("Error", "User not found", "OK");
                    return;
                }

                if (user.Password != Password.Text)
                {
                    await DisplayAlert("Error", "Incorrect password", "OK");
                    return;
                }

                if (user.Role == "Teacher")
                {
                    await Navigation.PushAsync(new TeacherPage());
                }
                else if (user.Role == "Student")
                {
                    await Navigation.PushAsync(new StudentPage());
                }
            }
        }

        public class Entry
        {
            public string Text { get; set; }
        }

        public class User
        {
            public int UserId { get; set; }
            public string Password { get; set; }
            public string Role { get; set; }
        }

        public class TeacherPage { }
        public class StudentPage { }
    }
}
