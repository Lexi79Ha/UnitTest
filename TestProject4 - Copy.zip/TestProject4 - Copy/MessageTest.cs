﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace CourseScheduler.Tests
{
    public class MessagePageTests
    {
        private readonly MessagePage _messagePage;
        private readonly MockDatabaseHelper _mockDatabaseHelper;
        private readonly MockMessageService _mockMessageService;
        private readonly MockUserManager _mockUserManager;

        public MessagePageTests()
        {
            // Initialize mock dependencies
            _mockDatabaseHelper = new MockDatabaseHelper();
            _mockMessageService = new MockMessageService();
            _mockUserManager = new MockUserManager();

            // Inject mocks into MessagePage
            _messagePage = new MessagePage(_mockDatabaseHelper, _mockMessageService, _mockUserManager);
        }

        [Fact]
        public async Task LoadMessages_ShouldLoadMessagesForTeacher()
        {
            // Arrange
            _mockUserManager.SetLoggedInUser(new MockUser { UserId = 1, Role = "Teacher" });
            _mockDatabaseHelper.SetTeacher(new MockTeacher { TeacherId = 101, UserId = 1 });

            var expectedMessages = new List<Messages>
            {
                new Messages { Note = "Test Message 1", TeacherId = 101 },
                new Messages { Note = "Test Message 2", TeacherId = 101 }
            };

            _mockMessageService.SetMessagesForTeacher(expectedMessages);

            // Act
            await _messagePage.LoadMessages();

            // Assert
            var loadedMessages = _messagePage.GetAllMessages();
            Assert.Equal(expectedMessages.Count, loadedMessages.Count); // Simplified assertion

            for (int i = 0; i < expectedMessages.Count; i++)
            {
                Assert.Equal(expectedMessages[i].Note, loadedMessages[i].Note);
                Assert.Equal(expectedMessages[i].TeacherId, loadedMessages[i].TeacherId);
            }
        }

        [Fact]
        public async Task SendMessage_ShouldSendMessageToTeacher()
        {
            // Arrange
            _mockUserManager.SetLoggedInUser(new MockUser { UserId = 2, Role = "Student" });
            _mockDatabaseHelper.SetStudent(new MockStudent { StudentId = 202, UserId = 2 });

            _messagePage.SetSelectedTeacher(101);
            _messagePage.SetMessageContent("Hello Teacher!", "Subject 1");

            // Act
            await _messagePage.OnSendMessageClicked(null, EventArgs.Empty);

            // Assert
            var messages = _mockDatabaseHelper.GetSavedMessages();
            Assert.Equal(1, messages.Count);
            Assert.Equal("Hello Teacher!", messages[0].Note);
            Assert.Equal("Subject 1", messages[0].Subject);
            Assert.Equal(101, messages[0].TeacherId);
        }
    }

    // Mock implementations for dependencies
    public class MockDatabaseHelper : IDatabaseHelper
    {
        private List<MockTeacher> _teachers = new();
        private List<MockStudent> _students = new();
        private List<Messages> _savedMessages = new();

        public void SetTeacher(MockTeacher teacher) => _teachers.Add(teacher);
        public void SetStudent(MockStudent student) => _students.Add(student);
        public List<Messages> GetSavedMessages() => _savedMessages;

        public Task<MockTeacher> GetTeacherByUserIdAsync(int userId)
        {
            return Task.FromResult(_teachers.FirstOrDefault(t => t.UserId == userId));
        }

        public Task<MockStudent> GetStudentByUserIdAsync(int userId)
        {
            return Task.FromResult(_students.FirstOrDefault(s => s.UserId == userId));
        }

        public Task AddMessageAsync(Messages message)
        {
            _savedMessages.Add(message);
            return Task.CompletedTask;
        }
    }

    public class MockMessageService : IMessageService
    {
        private List<Messages> _messagesForTeacher = new();

        public void SetMessagesForTeacher(List<Messages> messages) => _messagesForTeacher = messages;

        public Task<List<Messages>> GetMessagesForTeacherAsync(int teacherId)
        {
            return Task.FromResult(_messagesForTeacher.Where(m => m.TeacherId == teacherId).ToList());
        }
    }

    public class MockUserManager : IUserManager
    {
        private MockUser _loggedInUser;

        public void SetLoggedInUser(MockUser user) => _loggedInUser = user;

        public MockUser LoggedInUser => _loggedInUser;
    }

    // Main Class Definitions
    public class MessagePage
    {
        private readonly IDatabaseHelper _databaseHelper;
        private readonly IMessageService _messageService;
        private readonly IUserManager _userManager;
        private readonly List<Messages> _messages = new();
        private int _selectedTeacherId;
        private string _messageContent;
        private string _messageSubject;

        public MessagePage(IDatabaseHelper databaseHelper, IMessageService messageService, IUserManager userManager)
        {
            _databaseHelper = databaseHelper;
            _messageService = messageService;
            _userManager = userManager;
        }

        public async Task LoadMessages()
        {
            var user = _userManager.LoggedInUser;
            if (user.Role == "Teacher")
            {
                var teacher = await _databaseHelper.GetTeacherByUserIdAsync(user.UserId);
                if (teacher != null)
                {
                    _messages.AddRange(await _messageService.GetMessagesForTeacherAsync(teacher.TeacherId));
                }
            }
        }

        public void SetSelectedTeacher(int teacherId) => _selectedTeacherId = teacherId;
        public void SetMessageContent(string content, string subject)
        {
            _messageContent = content;
            _messageSubject = subject;
        }

        public async Task OnSendMessageClicked(object sender, EventArgs e)
        {
            var message = new Messages
            {
                TeacherId = _selectedTeacherId,
                Note = _messageContent,
                Subject = _messageSubject
            };

            await _databaseHelper.AddMessageAsync(message);
        }

        public List<Messages> GetAllMessages() => _messages;
    }

    // Entity and Interface Definitions
    public interface IDatabaseHelper
    {
        Task<MockTeacher> GetTeacherByUserIdAsync(int userId);
        Task<MockStudent> GetStudentByUserIdAsync(int userId);
        Task AddMessageAsync(Messages message);
    }

    public interface IMessageService
    {
        Task<List<Messages>> GetMessagesForTeacherAsync(int teacherId);
    }

    public interface IUserManager
    {
        MockUser LoggedInUser { get; }
    }

    public class Messages
    {
        public int TeacherId { get; set; }
        public string Note { get; set; }
        public string Subject { get; set; }
    }

    public class MockUser { public int UserId { get; set; } public string Role { get; set; } }
    public class MockTeacher { public int TeacherId { get; set; } public int UserId { get; set; } }
    public class MockStudent { public int StudentId { get; set; } public int UserId { get; set; } }
}
